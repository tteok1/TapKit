import { test, expect, _electron as electron, type ElectronApplication } from '@playwright/test';
import { mkdir, mkdtemp, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
let app: ElectronApplication;
const evidence = resolve('docs/evidence/P02-03/translation-target-2026-10-21');
const sentence = 'The amber lighthouse guides a small boat safely home.';
test.afterEach(async () => {
  await app?.close();
});

test('P02-03 translation echo shows an explicit failed translation without marking completion', async () => {
  test.setTimeout(180_000);
  await mkdir('.test-data', { recursive: true });
  await mkdir(evidence, { recursive: true });
  const dir = await mkdtemp(resolve('.test-data/P02-03 selection trigger '));
  await writeFile(resolve(dir, 'P02-02.fixture'), 'P02-02 isolated fixture');
  const env = Object.fromEntries(
    Object.entries({
      ...process.env,
      TAPKIT_DATA_DIR: dir,
      TAPKIT_CHAT_FIXTURE: 'P02-02',
      TAPKIT_TRANSLATION_ECHO_FIXTURE: '1',
    }).filter((r): r is [string, string] => r[1] !== undefined),
  );
  delete env.ELECTRON_RUN_AS_NODE;
  app = await electron.launch({ args: [resolve('apps/desktop')], env, chromiumSandbox: true });
  const page = await app.firstWindow();
  await expect(page.getByTestId('core-status')).toHaveText('本地核心已连接', { timeout: 125_000 });
  await app.evaluate(({ BrowserWindow }) =>
    BrowserWindow.getAllWindows()[0]!.setContentSize(1440, 900),
  );
  await page.keyboard.press('Control+n');
  await expect(page.locator('.chat-surface')).toHaveAttribute('data-session-id', /[0-9a-f-]{36}/);
  const input = page.getByLabel('输入草稿', { exact: true });
  await input.fill('\n\n# P02批测1019\n\n' + sentence + '\n\n');
  await page.getByRole('button', { name: '发送', exact: true }).click();
  const paragraph = page
    .locator('.chat-message.assistant .chat-markdown p')
    .filter({ hasText: sentence });
  await expect(paragraph).toBeVisible();
  await expect(page.getByRole('button', { name: '停止', exact: true })).toHaveCount(0);
  const toolbar = page.getByRole('toolbar', { name: '选区操作', exact: true });
  await paragraph.evaluate((el) => {
    (document.activeElement as HTMLElement)?.blur();
    const range = document.createRange();
    range.selectNodeContents(el);
    window.getSelection()!.removeAllRanges();
    window.getSelection()!.addRange(range);
  });
  await expect(toolbar).toBeVisible();
  await toolbar.getByRole('button', { name: '翻译', exact: true }).click();
  await expect(page.locator('.chat-message.assistant')).toHaveCount(2);
  const answer = page.locator('.chat-message.assistant').last();
  await expect(answer.locator('.chat-markdown')).toHaveText(sentence);
  await expect(answer).toContainText('翻译未完成：模型原样返回了所选内容。请重试或换一个模型。');
  await expect(page.locator('.chat-progress[role="status"]')).toContainText('部分完成');
  for (const width of [1440, 960]) {
    await app.evaluate(
      ({ BrowserWindow }, width) => BrowserWindow.getAllWindows()[0]!.setContentSize(width, 900),
      width,
    );
    await answer.scrollIntoViewIfNeeded();
    await page.screenshot({ path: resolve(evidence, `translation-echo-${width}.png`) });
  }
  const summary = await page.evaluate(async () => {
    const sessionId = document.querySelector<HTMLElement>('.chat-surface')!.dataset.sessionId!;
    const requestId = crypto.randomUUID().replace(/^(.{14})./, (_, s: string) => s + '7');
    const r = await window.tapkit.chatCommand({ requestId }, 'messages.list', { sessionId });
    if (!r.ok || !('messages' in r.data)) throw new Error('SNAPSHOT_FAILED');
    return {
      status: r.data.run?.status,
      errorCode: r.data.run?.errorCode,
      calls: r.data.run?.calls,
      answer: r.data.messages.at(-1)?.status,
    };
  });
  expect(summary).toMatchObject({
    status: 'partial',
    errorCode: 'TRANSLATION_UNCHANGED',
    calls: 1,
    answer: 'interrupted',
  });
  await writeFile(
    resolve(evidence, 'translation-echo-ui.json'),
    JSON.stringify(summary, null, 2) + '\n',
  );
});
